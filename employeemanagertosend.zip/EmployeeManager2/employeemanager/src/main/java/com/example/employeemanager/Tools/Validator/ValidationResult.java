package com.example.employeemanager.Tools.Validator;

import java.util.*;

public class ValidationResult {
    private final Map<String, String> errors = new HashMap<>();

    public void addError(String fieldName, String errorMessage) {
        errors.put(fieldName, errorMessage);
    }

    public Map<String, String> getErrors() {
        return errors;
    }

    public boolean isValid() {
        return errors.isEmpty();
    }
}

