package com.example.employeemanager.Entities;

public class EditEmployeeAddressDTO {
    private AddressDTO addressP;
    private AddressDTO addressC;

    public void setAddressP(AddressDTO addressP) {
        this.addressP = addressP;
    }
    public AddressDTO getAddressP() {
        return addressP;
    }

    public void setAddressC(AddressDTO addressC) {
        this.addressC = addressC;
    }
    public AddressDTO getAddressC() {
        return addressC;
    }
}
