package com.example.employeemanager.Tools.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.employeemanager.Entities.AddEmployeeDTO;
import com.example.employeemanager.Entities.EditEmployeeDTO;
import com.example.employeemanager.Repositories.DepartmentRepository;

@Component
public class ValidatorFactory {

    private final DepartmentRepository departmentRepository;

    @Autowired
    public ValidatorFactory(DepartmentRepository departmentRepository) {
        this.departmentRepository = departmentRepository;
    }

    @SuppressWarnings("unchecked")
    public <T> Validator<T> getValidator(Class<T> clazz) {
        if (clazz == AddEmployeeDTO.class) {
            return (Validator<T>) new EmployeeValidator(departmentRepository);
        }
        else if(clazz == EditEmployeeDTO.class) {
            return (Validator<T>) new EditEmployeeValidator();
        }
        // Add more validators as needed
        throw new IllegalArgumentException("No validator found for class: " + clazz.getName());
    }
}
