package com.example.employeemanager.Tools.Validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.example.employeemanager.Entities.*;

public class EditEmployeeValidator implements Validator<EditEmployeeDTO> {

    private static final String EMAIL_REGEX = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
    private static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX);
    private static final String PHONE_REGEX = "^\\+?[0-9. ()-]{7,25}$";
    private static final Pattern PHONE_PATTERN = Pattern.compile(PHONE_REGEX);

    public static boolean isValidContact(String phoneNumber) {
        Matcher matcher = PHONE_PATTERN.matcher(phoneNumber);
        return matcher.matches();
    }

    public static boolean isValidEmail(String email) {
        Matcher matcher = EMAIL_PATTERN.matcher(email);
        return matcher.matches();
    }

    @Override
    public ValidationResult validate(EditEmployeeDTO employee) {
        ValidationResult validationResult = new ValidationResult();

        if(employee.getEmail()!=null && !isValidEmail(employee.getEmail())) {
            validationResult.addError("email", "Invalid Email");
        }

        if(employee.getContact()!=null && !isValidContact(employee.getContact())) {
            validationResult.addError("contact", "Invalid Contact");
        }

        if (employee.getAadhar()!=null && employee.getSsn()!=null) {
            validationResult.addError("name", "Employee cannot have both Aadhar and SSN");
        }


        return validationResult;
    }
}

