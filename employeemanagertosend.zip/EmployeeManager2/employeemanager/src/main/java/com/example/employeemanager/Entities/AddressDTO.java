package com.example.employeemanager.Entities;

public class AddressDTO {

    private String city;
    private String street;
    private String state;
    private String country;
    private String addrType;

    // Getters and Setters

    public String getCity() {
        return city;
    }

    public String getStreet() {
        return street;
    }

    public String getState() {
        return state;
    }

    public String getCountry() {
        return country;
    }

    public String getAddrType() {
        return addrType;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String city;
        private String street;
        private String state;
        private String country;
        private String addrType;

        public Builder setCity(String city) {
            this.city = city;
            return this;
        }
    
        public Builder setStreet(String street) {
            this.street = street;
            return this;
        }
    
        public Builder setState(String state) {
            this.state = state;
            return this;
        }
    
        public Builder setCountry(String country) {
            this.country = country;
            return this;
        }
    
        public Builder setAddrType(String addrType) {
            this.addrType = addrType;
            return this;
        }

        public AddressDTO build() {
            AddressDTO addressDTO = new AddressDTO();
            addressDTO.city = this.city;
            addressDTO.street = this.street;
            addressDTO.state = this.state;
            addressDTO.country = this.country;
            addressDTO.addrType = this.addrType;
            return addressDTO;
        }
    }
}
