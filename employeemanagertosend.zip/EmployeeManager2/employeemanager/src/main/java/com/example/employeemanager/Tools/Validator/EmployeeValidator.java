package com.example.employeemanager.Tools.Validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.employeemanager.Entities.AddEmployeeDTO;
import com.example.employeemanager.Repositories.DepartmentRepository;

public class EmployeeValidator implements Validator<AddEmployeeDTO> {

    private static final String EMAIL_REGEX = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
    private static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX);
    private static final String PHONE_REGEX = "^\\+?[0-9. ()-]{7,25}$";
    private static final Pattern PHONE_PATTERN = Pattern.compile(PHONE_REGEX);

    public static boolean isValidContact(String phoneNumber) {
        Matcher matcher = PHONE_PATTERN.matcher(phoneNumber);
        return matcher.matches();
    }

    public static boolean isValidEmail(String email) {
        Matcher matcher = EMAIL_PATTERN.matcher(email);
        return matcher.matches();
    }

    @Autowired
    // private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;

    @Autowired
    public EmployeeValidator(DepartmentRepository departmentRepository) {
        // this.employeeRepository = employeeRepository;
        this.departmentRepository = departmentRepository;
    }
    

    @Override
    public ValidationResult validate(AddEmployeeDTO employee) {
        ValidationResult validationResult = new ValidationResult();

        if(employee.getName()==null) {
            validationResult.addError("name", "Name cannot be empty.");
        }

        if(employee.getEmail()==null) {
            validationResult.addError("email", "Email cannot be empty.");
        }
        else if(!isValidEmail(employee.getEmail())) {
            validationResult.addError("email", "Invalid Email");
        }

        if(employee.getContact()==null) {
            validationResult.addError("contact", "Contact cannot be empty.");
        }
        else if(!isValidContact(employee.getContact())) {
            validationResult.addError("contact", "Invalid Contact");
        }

        if(employee.getAddressP()==null || employee.getAddressC()==null) {
            validationResult.addError("address", "Address cannot be empty.");
        }

        if (employee.getAadhar()!=null && employee.getSsn()!=null) {
            validationResult.addError("aadhar", "Employee cannot have both Aadhar and SSN");
        }

        if(employee.getAddressC().getCountry().equalsIgnoreCase("india") && employee.getAadhar()==null) {
            validationResult.addError("aadhar", "Indian Employee needs to have Aadhar");
        }

        if(employee.getDepartment()!=null && !departmentRepository.existsByName(employee.getDepartment())) {
            validationResult.addError("department", "Department Does Not Exist.");
        }

        return validationResult;
    }
}

