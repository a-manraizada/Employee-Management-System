package com.example.employeemanager.Entities;

// import java.util.*;

public class EditEmployeeDTO {
	private String name;
	private String email;
	private String contact;
	private AddressDTO addressP;
    private AddressDTO addressC;
	private String aadhar;
	private String ssn;
	private String department;

    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getContact() {
		return contact;
	}

	public void setAddressP(AddressDTO addressP) {
		this.addressP = addressP;
	}

	public AddressDTO getAddressP() {
		return addressP;
	}

    public void setAddressC(AddressDTO addressC) {
		this.addressC = addressC;
	}

	public AddressDTO getAddressC() {
		return addressC;
	}

	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}

	public String getAadhar() {
		return aadhar;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getSsn() {
		return ssn;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public static Builder builder() {
		return new Builder();
	}

	public static class Builder {
		private String name;
		private String email;
		private String contact;
		private AddressDTO addressP;
		private AddressDTO addressC;
		private String aadhar;
		private String ssn;
		private String department;

		public Builder setName(String name) {
			this.name = name;
			return this;
		}

		public Builder setEmail(String email) {
			this.email = email;
			return this;
		}

		public Builder setContact(String contact) {
			this.contact = contact;
			return this;
		}

		public Builder setAddressP(AddressDTO addressP) {
			this.addressP = addressP;
			return this;
		}

		public Builder setAddressC(AddressDTO addressC) {
			this.addressC = addressC;
			return this;
		}

		public Builder setAadhar(String aadhar) {
			this.aadhar = aadhar;
			return this;
		}

		public Builder setSsn(String ssn) {
			this.ssn = ssn;
			return this;
		}

		public Builder setDepartment(String department) {
			this.department = department;
			return this;
		}

		public EditEmployeeDTO build() {
			EditEmployeeDTO editEmployeeDTO = new EditEmployeeDTO();
			editEmployeeDTO.name = this.name;
			editEmployeeDTO.email = this.email;
			editEmployeeDTO.contact = this.contact;
			editEmployeeDTO.addressP = this.addressP;
			editEmployeeDTO.addressC = this.addressC;
			editEmployeeDTO.aadhar = this.aadhar;
			editEmployeeDTO.ssn = this.ssn;
			editEmployeeDTO.department = this.department;
			return editEmployeeDTO;
		}

	}

}
