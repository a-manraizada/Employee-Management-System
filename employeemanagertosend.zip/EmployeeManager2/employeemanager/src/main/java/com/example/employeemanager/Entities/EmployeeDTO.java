package com.example.employeemanager.Entities;

import java.util.*;

public class EmployeeDTO {
    private Long id;
	private String name;
	private String email;
	private String contact;
	private List<AddressDTO> address;
	private String department;
	private String aadhar;
	private String ssn;

    public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public String getDepartment() {
		return department;
	}

	public Long getId() {
		return id;
	}

	public String getContact() {
		return contact;
	}

	public List<AddressDTO> getAddress() {
		return address;
	}

	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getAadhar() {
		return aadhar;
	}

	public String getSsn() {
		return ssn;
	}

	public static Builder builder() {
		return new Builder();
	}

	public static class Builder {
		private Long id;
		private String name;
		private String email;
		private String contact;
		private List<AddressDTO> address;
		private String department;
		private String aadhar;
		private String ssn;

		public Builder setName(String name) {
			this.name = name;
			return this;
		}

		public Builder setEmail(String email) {
			this.email = email;
			return this;
		}

		public Builder setDepartment(String dep) {
			department = dep;
			return this;
		}

		public Builder setId(Long id) {
			this.id = id;
			return this;
		}

		public Builder setContact(String contact) {
			this.contact = contact;
			return this;
		}

		public Builder setAddress(List<AddressDTO> address) {
			this.address = address;
			return this;
		}

		public Builder setAadhar(String aadhar) {
			this.aadhar = aadhar;
			return this;
		}

		public Builder setSsn(String ssn) {
			this.ssn = ssn;
			return this;
		}

		public EmployeeDTO build() {
			EmployeeDTO employeeDTO = new EmployeeDTO();
			employeeDTO.id = this.id;
			employeeDTO.name = this.name;
			employeeDTO.email = this.email;
			employeeDTO.contact = this.contact;
			employeeDTO.address = this.address;
			employeeDTO.department = this.department;
			employeeDTO.aadhar = this.aadhar;
			employeeDTO.ssn = this.ssn;
			return employeeDTO;
		}
	}

}
