package com.example.employeemanager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.employeemanager.Entities.AddEmployeeDTO;
import com.example.employeemanager.Entities.AddressDTO;
import com.example.employeemanager.Entities.EditEmployeeDTO;
import com.example.employeemanager.Entities.Employee;
import com.example.employeemanager.Entities.EmployeeDTO;
import com.example.employeemanager.Repositories.DepartmentRepository;
import com.example.employeemanager.Repositories.EmployeeRepository;
import com.example.employeemanager.Services.EmployeeService;
import com.example.employeemanager.Tools.Exceptions.EmployeeNotFoundException;
import com.example.employeemanager.Tools.Validator.ValidationResult;
import com.example.employeemanager.Tools.Validator.Validator;
import com.example.employeemanager.Tools.Validator.ValidatorFactory;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    private final ValidatorFactory validatorFactory;

    @Autowired
    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;


    @Autowired
    public EmployeeController(EmployeeService employeeService, ValidatorFactory validatorFactory, EmployeeRepository employeeRepository, DepartmentRepository departmentRepository) {
        this.employeeService = employeeService;
        this.validatorFactory = validatorFactory;
        this.employeeRepository = employeeRepository;
        this.departmentRepository = departmentRepository;
    }

    @PostMapping("/add")
    public ResponseEntity<?> addEmployee(@RequestBody AddEmployeeDTO employee) {
        Validator<AddEmployeeDTO> validator = validatorFactory.getValidator(AddEmployeeDTO.class);
        ValidationResult validationResult = validator.validate(employee);

        if(!validationResult.isValid()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(validationResult.getErrors());
        }
        employeeService.addEmployee(employee);
        return ResponseEntity.status(HttpStatus.CREATED).body("Employee was added Successfully!");
    }

    @DeleteMapping("/delete")
    public ResponseEntity<?> removeEmployee(@RequestParam Long id) {
        employeeService.removeEmployee(id);
        return ResponseEntity.status(HttpStatus.CREATED).body("Employee deleted successfully.");
    }

    @PatchMapping("/edit")
    public ResponseEntity<?> editEmployee(@RequestParam(required=true) Long id, @RequestBody(required=false) EditEmployeeDTO employee) {
        if(!employeeRepository.existsById(id)) {
            throw new EmployeeNotFoundException("Employee with id " + id + " not found.");

        }
        Validator<EditEmployeeDTO> validator = validatorFactory.getValidator(EditEmployeeDTO.class);
        ValidationResult validationResult = validator.validate(employee);
        if(!validationResult.isValid()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(validationResult.getErrors());
        }
        employeeService.editEmployee(id, employee);
        return ResponseEntity.status(HttpStatus.CREATED).body("Employee Edited Successfully");

    }

    @PutMapping("/assigndepartment")
    public ResponseEntity<?> assignToDepartment(@RequestParam Long employeeid, @RequestParam Long departmentid) {
        if(!departmentRepository.existsById(departmentid)) {
            throw new EmployeeNotFoundException("Employee with id " + departmentid + " not found.");
        }
        if(!employeeRepository.existsById(employeeid)) {
            throw new EmployeeNotFoundException("Employee with id " + employeeid + " not found.");
        }
        employeeService.assignToDepartment(employeeid, departmentid);
        return ResponseEntity.status(HttpStatus.CREATED).body("Department assigned");
    }

    @GetMapping("/employee")
    public ResponseEntity<?> getEmployeeById(@RequestParam(required=false) Long id) {
        List<EmployeeDTO> employees;
        employees = employeeService.getEmployeeById(id);
        return ResponseEntity.status(HttpStatus.CREATED).body(employees);
    }

    @GetMapping("/search")
    public List<EmployeeDTO> searchEmployee(@RequestParam(required=false) String name, @RequestParam(required=false) String contact, @RequestParam(required=false) String email, @RequestParam(required = false) String addressCity, @RequestParam(required = false) String addressStreet, @RequestParam(required = false) String addressState, @RequestParam(required = false) String addressCountry, @RequestParam(required=false) Long id) {
        AddressDTO address = null;
        if (addressCity != null || addressStreet != null || addressState != null || addressCountry != null) {
            address = AddressDTO.builder().setCity(addressCity).setStreet(addressStreet).setState(addressState).setCountry(addressCountry).build();
        }
        return employeeService.searchEmployees(name, contact, email, address, id);
    }

    @GetMapping("/test")
    public List<Employee> testingAPI(@RequestParam(required=false) String name, @RequestParam(required=false) String contact, @RequestParam(required=false) String email, @RequestParam(required = false) String addressCity, @RequestParam(required = false) String addressStreet, @RequestParam(required = false) String addressState, @RequestParam(required = false) String addressCountry, @RequestParam(required=false) Long id) {
        AddressDTO address = null;
        if (addressCity != null || addressStreet != null || addressState != null || addressCountry != null) {
            address = AddressDTO.builder().setCity(addressCity).setStreet(addressStreet).setState(addressState).setCountry(addressCountry).build();
        }
        return employeeService.testingAPI(name, contact, email, address, id);
    }
}
