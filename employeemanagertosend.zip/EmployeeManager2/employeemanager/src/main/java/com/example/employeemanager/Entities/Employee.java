package com.example.employeemanager.Entities;

import jakarta.persistence.*;
import java.util.*;

@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String name;
	private String email;
	private String contact;
	private String aadhar;
	private String ssn;

	@OneToMany(mappedBy="employee", cascade=CascadeType.ALL, orphanRemoval=true)
	private List<Address> address;

	@ManyToOne
	@JoinColumn(name="department_id")
	private Department department;

	public Employee() {

	}

	public static Builder builder() {
		return new Builder();
	}

	
	public static class Builder {
		private Long id;
        private String name;
        private String email;
        private String contact;
        private List<Address> address;
        private Department department;
		private String aadhar;
		private String ssn;
	
		public Builder setName(String name) {
			this.name = name;
			return this;
		}
	
	
		public Builder setEmail(String email) {
			this.email = email;
			return this;
		}
	
	
		public Builder setDepartment(Department dep) {
			department = dep;
			return this;
		}
	
	
		public Builder setId(Long id) {
			this.id = id;
			return this;
		}
	
	
		public Builder setContact(String contact) {
			this.contact = contact;
			return this;
		}
	
	
		public Builder setAddress(List<Address> address) {
			this.address = address;
			return this;
		}

		public Builder setAadhar(String aadhar) {
			this.aadhar = aadhar;
			return this;
		}

		public Builder setSsn(String ssn) {
			this.ssn = ssn;
			return this;
		}

		public Employee build() {
            Employee employee = new Employee();
            employee.id = this.id;
            employee.name = this.name;
            employee.email = this.email;
            employee.contact = this.contact;
            employee.address = this.address;
            employee.department = this.department;
			employee.aadhar = this.aadhar;
			employee.ssn = this.ssn;
            return employee;
        }
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public Department getDepartment() {
		return department;
	}

	public Long getId() {
		return id;
	}

	public String getContact() {
		return contact;
	}

	public List<Address> getAddress() {
		return address;
	}

	public String getAadhar() {
		return aadhar;
	}

	public String getSsn() {
		return ssn;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
}