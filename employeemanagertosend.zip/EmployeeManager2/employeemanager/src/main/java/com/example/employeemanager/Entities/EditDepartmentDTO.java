package com.example.employeemanager.Entities;


public class EditDepartmentDTO {
    private Long id;
    private String name;
    private String description;

    public void setId(Long id) {
        this.id = id;
    }
    public Long getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Long id;
        private String name;
        private String description;

        public Builder setId(Long id) {
            this.id = id;
            return this;
        }

        public Builder setName(String name) {
            this.name = name;
            return this;
        }

        public Builder setDescription(String description) {
            this.description = description;
            return this;
        }

        public EditDepartmentDTO build() {
            EditDepartmentDTO editDepartmentDTO = new EditDepartmentDTO();
            editDepartmentDTO.id = this.id;
            editDepartmentDTO.name = this.name;
            editDepartmentDTO.description = this.description;
            return editDepartmentDTO;
        }
    }
}
