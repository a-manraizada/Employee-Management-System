package com.example.employeemanager.Repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.employeemanager.Entities.*;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {


    List<Employee> findByDepartment(Department department);
	
    @Query("SELECT e FROM Employee e LEFT JOIN e.address a WHERE " + "(:name IS NULL OR e.name LIKE %:name%) AND " + "(:contact IS NULL OR e.contact LIKE %:contact%) AND " + "(:email IS NULL OR e.email LIKE %:email%) AND " + "(:addressCity IS NULL OR a.city LIKE %:addressCity%) AND " + "(:addressStreet IS NULL OR a.street LIKE %:addressStreet%) AND " + "(:addressState IS NULL OR a.state LIKE %:addressState%) AND " + "(:addressCountry IS NULL OR a.country LIKE %:addressCountry%) AND " + "(:id is NULL OR e.id = :id)")
    List<Employee> searchEmployees(@Param("name") String name, @Param("contact") String contact, @Param("email") String email, @Param("addressCity") String addressCity, @Param("addressStreet") String addressStreet, @Param("addressState") String addressState, @Param("addressCountry") String addressCountry, @Param("id") Long id);
}
                                                                                                                                                                                                                                