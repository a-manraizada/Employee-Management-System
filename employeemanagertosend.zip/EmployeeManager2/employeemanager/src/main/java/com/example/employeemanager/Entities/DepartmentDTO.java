package com.example.employeemanager.Entities;

import java.util.*;

public class DepartmentDTO {
    private Long id;
    private String name;
    private String description;
    private List<EmployeeDTO> employees;

    public void setId(Long id) {
        this.id = id;
    }
    public Long getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setEmployees(List<EmployeeDTO> employees) {
        this.employees = employees;
    }
    public List<EmployeeDTO> getEmployees() {
        return employees;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Long id;
        private String name;
        private String description;
        private List<EmployeeDTO> employees;

        public Builder setId(Long id) {
            this.id = id;
            return this;
        }

        public Builder setName(String name) {
            this.name = name;
            return this;
        }

        public Builder setDescription(String description) {
            this.description = description;
            return this;
        }

        public Builder setEmployees(List<EmployeeDTO> employees) {
            this.employees = employees;
            return this;
        }

        public DepartmentDTO build() {
            DepartmentDTO departmentDTO = new DepartmentDTO();
            departmentDTO.id = this.id;
            departmentDTO.name = this.name;
            departmentDTO.description = this.description;
            departmentDTO.employees = this.employees;
            return departmentDTO;
        }
    }
}
