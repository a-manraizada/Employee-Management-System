package com.example.employeemanager.Entities;

import jakarta.persistence.*;

@Entity
public class Address {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String city;
    private String street;
    private String state;
    private String country;
    private String addrType; // "P" for permanent, "C" for current


    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    public Long getId() {
        return id;
    }

    public String getCity() {
        return city;
    }

    public String getStreet() {
        return street;
    }

    public String getState() {
        return state;
    }

    public String getCountry() {
        return country;
    }

    public String getAddrType() {
        return addrType;
    }

    public Employee getEmployee() {
        return employee;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Long id;
        private String city;
        private String street;
        private String state;
        private String country;
        private String addrType;
        private Employee employee;

        public Builder setId(Long id) {
            this.id = id;
            return this;
        }

        public Builder setCity(String city) {
            this.city = city;
            return this;
        }
    
        public Builder setStreet(String street) {
            this.street = street;
            return this;
        }
    
        public Builder setState(String state) {
            this.state = state;
            return this;
        }
    
        public Builder setCountry(String country) {
            this.country = country;
            return this;
        }
    
        public Builder setAddrType(String addrType) {
            this.addrType = addrType;
            return this;
        }

        public Builder setEmployee(Employee employee) {
            this.employee = employee;
            return this;
        }

        public Address build() {
            Address address = new Address();
            address.id = this.id;
            address.city = this.city;
            address.street = this.street;
            address.state = this.state;
            address.country = this.country;
            address.addrType = this.addrType;
            address.employee = this.employee;
            return address;
        }
    }
}
