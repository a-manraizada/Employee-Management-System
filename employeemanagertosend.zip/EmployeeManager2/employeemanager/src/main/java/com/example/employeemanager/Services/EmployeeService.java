package com.example.employeemanager.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.employeemanager.Entities.*;
import com.example.employeemanager.Repositories.DepartmentRepository;
import com.example.employeemanager.Repositories.EmployeeRepository;
import com.example.employeemanager.Tools.Exceptions.*;



@Service
public class EmployeeService {

    @Autowired
    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;

    @Autowired
    public EmployeeService(EmployeeRepository employeeRepository, DepartmentRepository departmentRepository) {
        this.employeeRepository = employeeRepository;
        this.departmentRepository = departmentRepository;
    }

    public void addEmployee(AddEmployeeDTO employee) {
        String department = employee.getDepartment(); 
        Department departmentToAdd = departmentRepository.findByName(department).orElse(null); 
        List<Address> addressesToAdd = new ArrayList<>();

        

        Employee employeeToAdd = Employee.builder().setName(employee.getName()).setContact(employee.getContact()).setEmail(employee.getEmail()).setDepartment(departmentToAdd).setAadhar(employee.getAadhar()).setSsn(employee.getSsn()).build();        

        AddressDTO addressP = employee.getAddressP();
        Address addressPToAdd = Address.builder().setCity(addressP.getCity()).setStreet(addressP.getStreet()).setState(addressP.getState()).setCountry(addressP.getCountry()).setAddrType(addressP.getAddrType()).setEmployee(employeeToAdd).build();
        addressesToAdd.add(addressPToAdd);

        AddressDTO addressC = employee.getAddressC();
        Address addressCToAdd = Address.builder().setCity(addressC.getCity()).setStreet(addressC.getStreet()).setState(addressC.getState()).setCountry(addressC.getCountry()).setAddrType(addressC.getAddrType()).setEmployee(employeeToAdd).build();
        addressesToAdd.add(addressCToAdd);

        employeeToAdd.setAddress(addressesToAdd);

        employeeRepository.save(employeeToAdd);
    }

    public void removeEmployee(Long id) {
        if(!employeeRepository.existsById(id)) {
            throw new EmployeeNotFoundException("Employee with id " + id + " not found.");
        }
        employeeRepository.deleteById(id);
    }

    public void editEmployee(Long id, EditEmployeeDTO employeeDetails) {
        int permanentAddress = 0;
        int currentAddress = 1;

        Employee employee = employeeRepository.findById(id).get();

        if(employeeDetails.getName()!=null) {
            employee.setName(employeeDetails.getName());
        }
        if(employeeDetails.getEmail()!=null) {
            employee.setEmail(employeeDetails.getEmail());
        }
        if(employeeDetails.getContact()!=null) {
            employee.setContact(employeeDetails.getContact());
        }
        List<Address> addresses = employee.getAddress();
        if(addresses==null) {
            addresses = new ArrayList<>(2);
        }

        AddressDTO addressP = employeeDetails.getAddressP();
        AddressDTO addressC = employeeDetails.getAddressC();

        if(employeeDetails.getAadhar()!=null) {
            employee.setAadhar(employeeDetails.getAadhar());
        }
        if(employeeDetails.getSsn()!=null) {
            employee.setSsn(employeeDetails.getSsn());
        }

        if(employeeDetails.getAddressP()!=null) {
            Address address = Address.builder().setCity(addressP.getCity()).setStreet(addressP.getStreet()).setState(addressP.getState()).setCountry(addressP.getCountry()).setAddrType(addressP.getAddrType()).setEmployee(employee).build();
            addresses.set(permanentAddress, address);
        }
        if(addressC!=null) {
            Address address = Address.builder().setCity(addressC.getCity()).setStreet(addressC.getStreet()).setState(addressC.getState()).setCountry(addressC.getCountry()).setAddrType(addressC.getAddrType()).setEmployee(employee).build();
            addresses.set(currentAddress, address);
        }
        employee.setAddress(addresses);


        employeeRepository.save(employee);
    }

    public void assignToDepartment(Long employeeId, Long departmentid) {
        Employee employee = employeeRepository.findById(employeeId).orElseThrow(() -> new RuntimeException("Employee not found"));
        Optional<Department> departmentToAssign = departmentRepository.findById(departmentid);
        if(departmentToAssign.isPresent()) {
            employee.setDepartment(departmentToAssign.get());
        }
        employeeRepository.save(employee);
    }

    public List<EmployeeDTO> getAllEmployees() {
        List<Employee> employees = employeeRepository.findAll();
        List<EmployeeDTO> employeesInfo = new ArrayList<>();
        for(Employee employee:employees) {
            EmployeeDTO employeeInfo = EmployeeDTO.builder().setName(employee.getName()).setId(employee.getId()).setEmail(employee.getEmail()).setDepartment(employee.getDepartment() != null ? employee.getDepartment().getName() : null).setAadhar(employee.getAadhar()).setSsn(employee.getSsn()).setContact(employee.getContact()).setAddress(employee.getAddress().stream().map(address -> {
                AddressDTO addressDTO = AddressDTO.builder().setCity(address.getCity()).setStreet(address.getStreet()).setState(address.getState()).setCountry(address.getCountry()).setAddrType(address.getAddrType()).build();
                return addressDTO;
            }).toList()).build();

            employeesInfo.add(employeeInfo);
        }
        return employeesInfo;
    }

    public List<EmployeeDTO> getEmployeeById(Long id) {
        if(id==null) {
            return getAllEmployees();
        }
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new EmployeeNotFoundException("Employee with id " + id + " not found."));
        EmployeeDTO employeeInfo = EmployeeDTO.builder().setName(employee.getName()).setId(employee.getId()).setEmail(employee.getEmail()).setDepartment(employee.getDepartment() != null ? employee.getDepartment().getName() : null).setAadhar(employee.getAadhar()).setSsn(employee.getSsn()).setContact(employee.getContact()).setAddress(employee.getAddress().stream().map(address -> {
            AddressDTO addressDTO = AddressDTO.builder().setCity(address.getCity()).setStreet(address.getStreet()).setState(address.getState()).setCountry(address.getCountry()).setAddrType(address.getAddrType()).build();
            return addressDTO;
        }).toList()).build();

        List<EmployeeDTO> employees = new ArrayList<>();

        employees.add(employeeInfo);

        return employees;
    }


    public List<EmployeeDTO> searchEmployees(String name, String contact, String email, AddressDTO address, Long id) {
        List<Employee> employees = employeeRepository.searchEmployees(
            name, 
            contact, 
            email, 
            address != null ? address.getCity() : null,
            address != null ? address.getStreet() : null,
            address != null ? address.getState() : null,
            address != null ? address.getCountry() : null, 
            id
        );
        List<EmployeeDTO> employeesInfo = new ArrayList<>();
        for(Employee employee:employees) {
            EmployeeDTO.Builder employeeInfo = EmployeeDTO.builder().setName(employee.getName()).setId(employee.getId()).setDepartment(employee.getDepartment() != null ? employee.getDepartment().getName() : null).setEmail(employee.getEmail()).setContact(employee.getContact()).setAadhar(employee.getAadhar()).setSsn(employee.getSsn());
            if(employee.getAddress()!=null) {
                employeeInfo.setAddress(employee.getAddress().stream().map(addr -> {
                    AddressDTO addressDTO = AddressDTO.builder().setCity(addr.getCity()).setStreet(addr.getStreet()).setState(addr.getState()).setCountry(addr.getCountry()).setAddrType(addr.getAddrType()).build();
                    return addressDTO;
                }).toList());
            }

            employeesInfo.add(employeeInfo.build());
        }
        return employeesInfo;
    }

    public List<Employee> testingAPI(String name, String contact, String email, AddressDTO address, Long id) {
        List<Employee> employees = employeeRepository.searchEmployees(
            name, 
            contact, 
            email, 
            address != null ? (address.getCity()!=null ? address.getCity() : null) : null,
            address != null ? (address.getStreet()!=null ? address.getStreet() : null) : null,
            address != null ? (address.getState()!=null ? address.getState() : null) : null,
            address != null ? (address.getCountry()!=null ? address.getCountry() : null) : null, 
            id
        );
        return employees;
    }

}
