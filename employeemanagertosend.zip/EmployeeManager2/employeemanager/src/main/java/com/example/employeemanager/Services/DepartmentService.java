package com.example.employeemanager.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import java.util.*;

import com.example.employeemanager.Entities.*;
import com.example.employeemanager.Repositories.*;

@Service
public class DepartmentService {
    
    @Autowired
    private final DepartmentRepository departmentRepository;

    public DepartmentService(DepartmentRepository departmentRepository) {
        this.departmentRepository = departmentRepository;
    }

    public ResponseEntity<?> addDepartment(String department, Long id) {
        if(departmentRepository.existsById(id)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Department Already exists.");
        }
        Department departmentToAdd = Department.builder().setName(department).setId(id).build();
        departmentRepository.save(departmentToAdd);
        return ResponseEntity.status(HttpStatus.CREATED).body("Department Created Successfully.");
    }

    public List<DepartmentDTO> getAllDepartments() {
        List<Department> departments = departmentRepository.findAll();
        List<DepartmentDTO> departmentsInfo = new ArrayList<>();
        for(Department department: departments) {
            DepartmentDTO.Builder departmentInfo = DepartmentDTO.builder().setName(department.getName()).setId(department.getId());
            List<Employee> employees = department.getEmployees();
            List<EmployeeDTO> employeesToShow = new ArrayList<>();
            for(Employee employee:employees) {
                EmployeeDTO employeeToShow = EmployeeDTO.builder().setName(employee.getName()).setId(employee.getId()).setContact(employee.getContact()).setEmail(employee.getEmail()).setAddress(employee.getAddress().stream().map(address -> {
                    AddressDTO addressDTO = AddressDTO.builder().setCity(address.getCity()).setStreet(address.getStreet()).setState(address.getState()).setCountry(address.getCountry()).setAddrType(address.getAddrType()).build();
                    return addressDTO;
                }).toList()).setDepartment(employee.getDepartment().getName()).build();

                employeesToShow.add(employeeToShow);
            }
            departmentInfo.setEmployees(employeesToShow);

            departmentsInfo.add(departmentInfo.build());
        }
        return departmentsInfo;
    }

    public DepartmentDTO getDepartment(Long id) {
        Department department = departmentRepository.findById(id).orElseGet(null);
        DepartmentDTO.Builder departmentInfo = DepartmentDTO.builder().setName(department.getName()).setId(department.getId());
        List<Employee> employees = department.getEmployees();
        List<EmployeeDTO> employeesToShow = new ArrayList<>();
        for(Employee employee:employees) {
            EmployeeDTO employeeToShow = EmployeeDTO.builder().setName(employee.getName()).setId(employee.getId()).build();

            employeesToShow.add(employeeToShow);
        }
        departmentInfo.setEmployees(employeesToShow);
        return departmentInfo.build();
    }

    public ResponseEntity<?> editDepartment(EditDepartmentDTO editDepartmentDTO) {
        Department department = departmentRepository.findById(editDepartmentDTO.getId()).orElseGet(null);
        if(editDepartmentDTO.getName()!=null) {
            department.setName(editDepartmentDTO.getName());
        }
        if(editDepartmentDTO.getDescription()!=null) {
            department.setDescription(editDepartmentDTO.getDescription());
        }

        departmentRepository.save(department);
        return ResponseEntity.status(HttpStatus.CREATED).body("Department Edited Successfully.");

    }
}
