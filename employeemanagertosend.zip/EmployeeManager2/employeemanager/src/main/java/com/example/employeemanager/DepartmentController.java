package com.example.employeemanager;

import com.example.employeemanager.Entities.*;
import com.example.employeemanager.Services.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import java.util.*;


@RestController
@RequestMapping("/departments")
public class DepartmentController {
    
    private final DepartmentService departmentService;

    @Autowired
    public DepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    @PostMapping("/add")
    public ResponseEntity<?> addDepartment(@RequestParam String department, @RequestParam Long id) {
        return departmentService.addDepartment(department, id);
    }

    @GetMapping
    public List<DepartmentDTO> getAllDepartments() {
        return departmentService.getAllDepartments();
    }

    @GetMapping("/department")
    public DepartmentDTO getDepartment(@RequestParam Long id) {
        return departmentService.getDepartment(id);
    }
}
