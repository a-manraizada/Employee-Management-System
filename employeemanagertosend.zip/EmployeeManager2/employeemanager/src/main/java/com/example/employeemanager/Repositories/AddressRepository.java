package com.example.employeemanager.Repositories;

import com.example.employeemanager.Entities.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Long> {
}
