package com.example.employeemanager.Tools.Validator;

public interface Validator<T> {
    ValidationResult validate(T object);
}